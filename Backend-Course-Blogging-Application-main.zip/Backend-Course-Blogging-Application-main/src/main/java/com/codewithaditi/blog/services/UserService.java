package com.codewithaditi.blog.services;

import java.util.List;

import com.codewithaditi.blog.entities.User;
import com.codewithaditi.blog.payloads.UserDto;

public interface UserService {

	UserDto registerNewUser(UserDto user);
	
	
	UserDto createUser(UserDto user);

	UserDto updateUser(UserDto user, Integer userId);

	UserDto getUserById(Integer userId);

	List<UserDto> getAllUsers();

	void deleteUser(Integer userId);


	void generateOtp(String email) throws Exception;


	void verifyOtpAndResetPassword(String email, String otp, String newPassword);


	User findByEmail(String email);


	void save(User user);


	

}
