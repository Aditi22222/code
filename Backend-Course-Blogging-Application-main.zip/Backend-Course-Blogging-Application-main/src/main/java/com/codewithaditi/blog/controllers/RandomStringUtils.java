package com.codewithaditi.blog.controllers;

public class RandomStringUtils {

	public static String randomNumeric(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
