package com.codewithaditi.blog.exceptions;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResourceNotFoundException extends RuntimeException {

	public ResourceNotFoundException(String string, String string2, Integer userId) {
		// TODO Auto-generated constructor stub
	}
	String resourceName;
	String fieldName;
	long fieldValue;

	

}
